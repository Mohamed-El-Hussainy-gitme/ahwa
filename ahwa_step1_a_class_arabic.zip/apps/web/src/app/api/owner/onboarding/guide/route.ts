import { ok, jsonError, requireOpsActorContext, requireOwnerRole } from '@/app/api/ops/_helpers';
import { supabaseAdminForDatabase } from '@/lib/supabase/admin';

function ops(databaseKey: string) {
  return supabaseAdminForDatabase(databaseKey).schema('ops');
}

export async function GET() {
  try {
    const ctx = requireOwnerRole(await requireOpsActorContext());
    const admin = ops(ctx.databaseKey);

    const [sectionsRes, productsRes, staffRes, shiftRes] = await Promise.all([
      admin.from('menu_sections').select('id', { count: 'exact', head: true }).eq('cafe_id', ctx.cafeId).eq('is_active', true),
      admin.from('menu_products').select('id', { count: 'exact', head: true }).eq('cafe_id', ctx.cafeId).eq('is_active', true),
      admin.from('staff_members').select('id', { count: 'exact', head: true }).eq('cafe_id', ctx.cafeId).eq('employment_status', 'active').eq('is_active', true),
      admin.from('shifts').select('id', { count: 'exact', head: false }).eq('cafe_id', ctx.cafeId).eq('status', 'open').order('opened_at', { ascending: false }).limit(1).maybeSingle(),
    ]);

    if (sectionsRes.error) throw sectionsRes.error;
    if (productsRes.error) throw productsRes.error;
    if (staffRes.error) throw staffRes.error;
    if (shiftRes.error) throw shiftRes.error;

    const openShiftId = shiftRes.data ? String(shiftRes.data.id) : null;
    let assignmentsCount = 0;
    if (openShiftId) {
      const assignmentsRes = await admin
        .from('shift_role_assignments')
        .select('id', { count: 'exact', head: true })
        .eq('cafe_id', ctx.cafeId)
        .eq('shift_id', openShiftId)
        .eq('is_active', true);
      if (assignmentsRes.error) throw assignmentsRes.error;
      assignmentsCount = assignmentsRes.count ?? 0;
    }

    const sectionsCount = sectionsRes.count ?? 0;
    const productsCount = productsRes.count ?? 0;
    const staffCount = staffRes.count ?? 0;
    const hasOpenShift = !!openShiftId;
    const hasAssignments = assignmentsCount > 0;

    const steps = [
      {
        key: 'menu',
        shortLabel: 'المنيو',
        title: 'أنشئ المنيو',
        description: 'أضف الأقسام والأصناف والأسعار حتى تظهر لمضيف الصالة ومختص الشيشة والباريستا.',
        done: sectionsCount > 0 && productsCount > 0,
      },
      {
        key: 'staff',
        shortLabel: 'فريق العمل',
        title: 'أضف الموظفين',
        description: 'أدخل الموظفين برمز PIN حتى يصبحوا جاهزين للتعيين والعمل.',
        done: staffCount > 0,
      },
      {
        key: 'shift',
        shortLabel: 'الوردية',
        title: 'افتح وردية',
        description: 'افتح وردية صباحي أو مسائي لبدء التشغيل الفعلي داخل القهوة.',
        done: hasOpenShift,
      },
      {
        key: 'roles',
        shortLabel: 'الأدوار',
        title: 'حدّد الأدوار',
        description: 'عيّن مضيف الصالة والباريستا ومختص الشيشة ومشرف التشغيل داخل الوردية المفتوحة.',
        done: hasOpenShift && hasAssignments,
      },
    ] as const;

    return ok({
      intro:
        'ابدأ بإنشاء المنيو ثم أضف فريق العمل، وبعدها افتح وردية وعيّن الأدوار. مضيف الصالة يأخذ الطلبات من الزبائن ويسلمها للباريستا أو مختص الشيشة، وبعد التجهيز يستلم الجاهز ويسلمه للزبائن، ثم يتم التحصيل الفردي لكل شخص داخل جلسته، وبعدها تظهر التقارير والآجل تلقائيًا.',
      sectionsCount,
      productsCount,
      staffCount,
      hasOpenShift,
      roleAssignmentsCount: assignmentsCount,
      totalCount: steps.length,
      completedCount: steps.filter((step) => step.done).length,
      completionPercent: Math.round((steps.filter((step) => step.done).length / steps.length) * 100),
      readyToRun: steps.every((step) => step.done),
      steps,
    });
  } catch (error) {
    return jsonError(error, 400);
  }
}
