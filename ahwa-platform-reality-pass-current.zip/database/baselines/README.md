# Fresh database baselines

- `operational/0001_fresh_operational_baseline.sql`: fresh operational database install bundle for **new operational shards only**.
- `control-plane/0001_fresh_control_plane_baseline.sql`: control-plane-only bundle for the fixed control-plane database (for example `db01`).

These files are generated from `database/migrations/*`.
Use the operational bundle for newly provisioned runtime databases that do **not** host the control plane.
Use the control-plane bundle only for the single database that owns the control/control-plane schema and registration flow.
Live databases must continue to move forward through the historical migration chain.

## Three-database topology

- `db01`: apply `operational/0001_fresh_operational_baseline.sql` first, then apply `control-plane/0001_fresh_control_plane_baseline.sql` on the same database because it hosts both operational + control-plane schemas.
- `db02`: apply `operational/0001_fresh_operational_baseline.sql` only.
- `db03`: apply `operational/0001_fresh_operational_baseline.sql` only.

For already-running databases, keep using the numbered migrations. For the current topology that means:

1. Apply `0064_ops_runtime_presence_platform_reality.sql` to every operational database: `db01`, `db02`, and `db03`.
2. Apply `0065_control_plane_runtime_presence_platform_reality.sql` to `db01` only.
3. Apply `0066_control_plane_platform_last_open_order_summary.sql` to `db01` only.

Regenerate after any migration change with:

```bash
npm run build:db-baselines
```

Operational bundle includes: 0001_replace_old_with_runtime_v3.sql, 0002_phase2_bootstrap_and_ops.sql, 0003_phase2_station_delivery_ops.sql, 0004_complete_remaining_database.sql, 0005_platform_auth_and_owner_listing.sql, 0006_ops_hardening_and_rls.sql, 0007_runtime_actor_identity_bindings.sql, 0008_runtime_local_auth_and_staff_codes.sql, 0009_pgcrypto_schema_qualification.sql, 0010_phase3_complaints_cancel_and_waive.sql, 0011_phase1_platform_partners_and_subscriptions.sql, 0012_phase2_menu_management.sql, 0013_phase3_remake_delivery_fix.sql, 0014_shift_resume_latest_and_single_row.sql, 0015_session_label.sql, 0016_phaseA_platform_portfolio_overview.sql, 0017_phaseB_platform_cafe_detail.sql, 0018_reconcile_multi_shisha_shift_roles.sql, 0019_split_general_complaints_from_item_issues.sql, 0020_canonical_shift_snapshots_and_time_reports.sql, 0021_platform_privacy_refactor_and_admin_views.sql, 0022_remove_support_grants_and_lock_final_access.sql, 0023_platform_subscription_money_follow_and_create_flow.sql, 0024_staff_employment_status_lifecycle.sql, 0025_ops_idempotency_for_sensitive_mutations.sql, 0026_platform_support_inbox_and_dashboard_refactor.sql, 0027_weekly_archiving_rollups.sql, 0028_operational_scope_monthly_yearly_rollups.sql, 0029_runtime_reporting_contract_and_deferred_balances.sql, 0030_archive_scheduler_and_backfill_reconciliation.sql, 0031_archive_approval_and_post_archive_checks.sql, 0032_deferred_finance_non_archival_policy.sql, 0033_search_path_security_hardening.sql, 0040_ops_atomic_shift_open_with_assignments.sql, 0042_owner_password_setup_runtime_readiness.sql, 0045_remove_service_station_code.sql, 0046_owner_phone_normalization_uniqueness.sql, 0047_ops_outbox_and_realtime_dispatch.sql, 0049_ops_observability_snapshots.sql, 0051_ops_billing_extras_and_receipt_support.sql, 0052_ops_order_note_presets.sql, 0053_ops_menu_addons_foundation.sql, 0054_ops_incremental_rls_for_recent_tables.sql, 0055_search_path_linter_cleanup.sql, 0056_control_plane_runtime_activity_read_model.sql, 0057_branch_manager_and_american_waiter.sql, 0057_ops_runtime_status_snapshot_export.sql, 0060_owner_management_and_shift_role_expansion.sql, 0061_operational_branch_manager_owner_label.sql, 0062_control_plane_branch_manager_owner_functions.sql, 0063_ops_pwa_push_subscriptions.sql, 0064_ops_runtime_presence_platform_reality.sql

Control-plane bundle includes: 0034_control_plane_manual_database_selection.sql, 0035_phase8_strict_control_plane_bindings.sql, 0036_platform_response_hardening.sql, 0037_control_plane_public_binding_readers.sql, 0038_control_plane_create_flow_binding_upsert.sql, 0039_control_plane_operational_database_registration.sql, 0041_support_access_on_demand.sql, 0043_control_plane_owner_password_setup_flow.sql, 0044_control_plane_owner_password_setup_preflight.sql, 0048_control_plane_scale_discipline.sql, 0050_restore_owner_activation_code_flow_after_scale_discipline.sql, 0065_control_plane_runtime_presence_platform_reality.sql, 0066_control_plane_platform_last_open_order_summary.sql
